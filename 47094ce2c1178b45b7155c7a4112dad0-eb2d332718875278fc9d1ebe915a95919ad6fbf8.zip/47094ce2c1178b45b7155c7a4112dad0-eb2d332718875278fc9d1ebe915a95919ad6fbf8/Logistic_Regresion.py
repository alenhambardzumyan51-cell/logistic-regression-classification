import matplotlib.pyplot as plt
import numpy as np
from sklearn.datasets import make_classification
from sklearn.linear_model import LogisticRegression

X, y = make_classification(
    n_samples = 300,
    n_features = 2,
    n_classes = 2,
    n_redundant = 0,
    n_informative = 2,
    random_state = 42
)

model = LogisticRegression(max_iter = 1000, random_state = 42)
model = model.fit(X, y)

x_min, x_max = X[:,0].min() - 1, X[:,0].max() + 1
y_min, y_max = X[:,1].min() - 1, X[:,1].max() + 1
xx, yy = np.meshgrid(
    np.linspace(x_min, x_max, 400),
    np.linspace(y_min, y_max, 400)
)

grid = np.c_[xx.ravel(), yy.ravel()]
proba = model.predict_proba(grid)[:,1].reshape(xx.shape)

plt.figure(figsize = (7, 5))
plt.contourf(xx, yy, proba, levels = 20 , alpha = 0.3, cmap = plt.cm.coolwarm)
plt.contour(xx, yy, proba, levels = [0.5], linewidths = 3, colors = 'black')
plt.contour(xx, yy, proba, levels = [0.2, 0.8], colors = 'black', linewidths = 2)

plt.scatter(X[:,0], X[:,1], cmap = plt.cm.coolwarm, edgecolors = 'black', c = y)
plt.xlabel('sign 1')
plt.ylabel('sign 2')
plt.title('Classification: logistic regression')
plt.tight_layout()
plt.show()
